//
//  NSObject+AlanKVO.m
//  CustomKVO
//
//  Created by Alan on 2018/4/25.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import "NSObject+AlanKVO.h"
#import <objc/message.h>

@implementation NSObject (AlanKVO)

void setName (id self,SEL _cmd, NSString *newName){
    id class = [self class];
    object_setClass(self, class_getSuperclass([self class]));
    objc_msgSend(self,@selector(setName:),newName);
    id observer = objc_getAssociatedObject(self, (__bridge const void *)@"123");
    objc_msgSend(observer, @selector(Alan_observeValueForKeyPath:ofObject:change:context:),self,@"name",@{@"new":newName},nil);
    object_setClass(self, class);

}
- (void)Alan_observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context;
{
    
}

- (void)alan_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath options:(NSKeyValueObservingOptions)options context:(void *)context
{
    /**
        动态创建一个类
     */
    NSString * oldClassName = NSStringFromClass([self class]);
    NSString *newClassName = [@"AlanKVO_" stringByAppendingString:oldClassName];
    const char * newName = [newClassName UTF8String];

    //定义一个类
    Class myClass = objc_allocateClassPair([self class], newName, 0);

    //重写set方法
    class_addMethod(myClass, @selector(setName:), (IMP)setName, "alan");
    //注册这个类
    objc_registerClassPair(myClass);
    //改变isa指针
    object_setClass(self, myClass);

    //绑定
    objc_setAssociatedObject(self, (__bridge const void *)@"123", observer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}


@end
