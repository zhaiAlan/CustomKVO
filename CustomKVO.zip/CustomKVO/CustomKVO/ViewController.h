//
//  ViewController.h
//  CustomKVO
//
//  Created by Alan on 2018/4/25.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

