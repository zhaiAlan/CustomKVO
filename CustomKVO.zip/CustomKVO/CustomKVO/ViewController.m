//
//  ViewController.m
//  CustomKVO
//
//  Created by Alan on 2018/4/25.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
#import "NSObject+AlanKVO.h"


@interface ViewController ()
@property (nonatomic, strong) Person *p;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _p = [[Person alloc]init];
//    [_p addObserver:self forKeyPath:@"name" options:NSKeyValueObservingOptionNew context:nil];
//    _p.age = 1;
    [_p addObserver:self forKeyPath:@"_sex" options:NSKeyValueObservingOptionNew context:nil];
//    [_p alan_addObserver:self forKeyPath:@"name" options:NSKeyValueObservingOptionNew context:nil];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    NSLog(@"观察");
}
- (void)Alan_observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    NSLog(@"alan观察");
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    _p.name = @"Alan";
    _p.age = 11;
    _p->_sex = @"boy";
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
